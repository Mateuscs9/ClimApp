package com.example.climapp.Models

data class Coord(
    val lat: Double,
    val lon: Double
)