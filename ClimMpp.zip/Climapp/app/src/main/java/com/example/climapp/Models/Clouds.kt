package com.example.climapp.Models

data class Clouds(
    val all: Int
)