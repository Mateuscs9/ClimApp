package com.example.climapp.Models

data class Rain(
    val `1h`: Double
)